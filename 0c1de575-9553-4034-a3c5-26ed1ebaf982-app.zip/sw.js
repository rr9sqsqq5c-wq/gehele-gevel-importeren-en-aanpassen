const CACHE = 'brickslip-v1';

const PRECACHE = [
  '/',
  '/index.html',
  '/web-ifc-api-iife.js',
  '/web-ifc.wasm',
  '/web-ifc-mt.wasm',
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  if (url.origin !== self.location.origin) return;

  e.respondWith(
    caches.match(e.request).then((cached) => {
      const fetchPromise = fetch(e.request).then((response) => {
        if (response.ok) {
          caches.open(CACHE).then((c) => c.put(e.request, response.clone()));
        }
        return response;
      }).catch(() => cached);
      return cached ?? fetchPromise;
    })
  );
});
